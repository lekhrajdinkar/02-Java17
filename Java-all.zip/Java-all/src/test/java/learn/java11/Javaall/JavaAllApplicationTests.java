package learn.java11.Javaall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaAllApplicationTests {

	@Test
	void contextLoads() {
	}

}
